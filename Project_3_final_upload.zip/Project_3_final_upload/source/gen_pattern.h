/******************************************************************************
								PES PROJECT 3
   	   	   AAKSHA JAYWANT (AAJA1276) & RUCHA BORWANKAR (RUBO1268)
                   Cross Platform IDE: MCUXpresso IDE v11
                   Compiler: MinGW/GNU gcc v8.2.0 (PC version)
                       Cross-Compiler: ARM GCC (FB version)
 	 	 	 	 	 	 	        GEN_PATTERN.C
********************************************************************************/


#include <stdint.h>
#include <stdio.h>


#ifndef _PATTERNGEN_H_
#define _PATTERNGEN_H_

void gen_pattern(uint8_t *pattern,size_t length_1,int8_t seed);


#endif /* SOURCE_MAIN_H_ */
